package com.ticket;


import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
//import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.jdbc.DataSourceAutoConfiguration;
import org.springframework.boot.autoconfigure.jdbc.XADataSourceAutoConfiguration;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.annotation.EnableScheduling;

@Configuration
@EnableAutoConfiguration
@ComponentScan
//@SpringBootApplication
@EnableScheduling

//@EnableAutoConfiguration(exclude={DataSourceAutoConfiguration.class, XADataSourceAutoConfiguration.class})
//@SpringBootApplication
public class TicketPassengerApplication {

    public static void main(String[] args) {
       SpringApplication springApplication=new SpringApplication(TicketPassengerApplication.class);
      springApplication.run(args);
//SpringApplication.run(TicketPassengerApplication.class, args);

    }
}
