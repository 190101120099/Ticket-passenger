package com.ticket.controller;
import com.ticket.entities.Passenger;
import com.ticket.service.PassengerService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
public class PassengerController {

    @Autowired
    private PassengerService passengerService;

    @GetMapping("/passengers")
    public List<Passenger>getPassenger() {
        return this.passengerService.getAllPassenger();
    }


    @GetMapping("/passengers/{id}")
    public Passenger getPassenger(@PathVariable("id") int id) {
        return passengerService.getPassengerById(id);
    }


    @PostMapping("/passengers")
    public Passenger addPassenger(@RequestBody Passenger passenger) {
        Passenger bg1 = this.passengerService.addPassenger(passenger);
        System.out.println(passenger);
        return bg1;
    }


    // delete PassengerController  handler
    @DeleteMapping("/passengers/{passengerId}")
    public void deletePassenger(@PathVariable("passengerId") int passengerId) {
        this.passengerService.deletePassenger(passengerId);
    }

    // update PassengerController  handler
    @PutMapping("/passengers/{passengerId}")
    public Passenger updatePassenger(@RequestBody Passenger passenger, @PathVariable
            ("passengerId") int passengerId) {
        this.passengerService.updatePassenger(passenger, passengerId);
        return passenger;
    }
}
