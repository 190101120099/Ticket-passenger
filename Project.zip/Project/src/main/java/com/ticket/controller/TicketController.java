
package com.ticket.controller;
import com.ticket.entities.Ticket;
import com.ticket.service.TicketService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;


@RestController
public class TicketController {

    @Autowired
    private TicketService ticketService;

    @GetMapping("/tickets")
    public List<Ticket> getTickets(){
        return  this.ticketService.getAllTickets();
    }

    @GetMapping("/tickets/{id}")
    public Ticket getTicket(@PathVariable("id") int id) {
        return ticketService.getTicketById(id);
    }

    @PostMapping("/tickets")
    public Ticket addTicket(@RequestBody Ticket ticket) {
        Ticket b =this.ticketService .addTicket(ticket);
            System.out.println(ticket);
        return b;
    }

    @DeleteMapping("/tickets/{ticketId}")
    public void deleteAuthor(@PathVariable("ticketId") int ticketId) {
        this.ticketService.deleteTicket(ticketId);
    }

    @PutMapping("/tickets/{ticketId}")
    public Ticket updateTicket(@RequestBody Ticket ticket, @PathVariable("ticketId") int ticketId)
    {
        this.ticketService.updateTicket(ticket, ticketId);
        return ticket;
    }
}