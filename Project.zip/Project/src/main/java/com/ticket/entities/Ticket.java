package com.ticket.entities;


import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import java.util.Date;

@Entity

public class Ticket {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int ticketId;
    private String  flightName;
    private int ticketAmount;
    private int pnrNo;
    private Date travelDate;
    private String source;
    private String destination;


    public int getTicketId() {
        return ticketId;
    }

    public void setTicketId(int ticketId) {
        this.ticketId = ticketId;
    }

    public String getFlightName() {
        return flightName;
    }

    public void setFlightName(String flightName) {
        this.flightName = flightName;
    }

    public int getTicketAmount() {
        return ticketAmount;
    }

    public void setTicketAmount(int ticketAmount) {
        this.ticketAmount = ticketAmount;
    }


    public int getPnrNo() {
        return pnrNo;
    }

    public void setPnrNo(int pnrNo) {
        this.pnrNo = pnrNo;
    }

    public Date getTravelDate() {
        return travelDate;
    }

    public void setTravelDate(Date travelDate) {
        this.travelDate = travelDate;
    }

    public String getSource() {
        return source;
    }

    public void setSource(String source) {
        this.source = source;
    }

    public String getDestination() {
        return destination;
    }

    public void setDestination(String destination) {
        this.destination = destination;
    }


    public Ticket(int ticketId, String flightName, int ticketAmount, Date date, int pnrNo, Date travelDate, String source, String destination) {
        this.ticketId = ticketId;
        this.flightName = flightName;
        this.ticketAmount = ticketAmount;
        this.pnrNo = pnrNo;
        this.travelDate = travelDate;
        this.source = source;
        this.destination = destination;
    }


    @Override
    public String toString() {
        return "TicketEntity{" +
                "ticketId=" + ticketId +
                ", flightName='" + flightName + '\'' +
                ", ticketAmount=" + ticketAmount +
                ", pnrNo=" + pnrNo +
                ", travelDate=" + travelDate +
                ", source='" + source + '\'' +
                ", destination='" + destination + '\'' +
                '}';
    }

    }

