package com.ticket.service;

import com.ticket.entities.Passenger;
import com.ticket.repository.PassengerRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class PassengerService {

     @Autowired
    private PassengerRepository passengerRepository;


    // get all PassengerService
    public List<Passenger> getAllPassenger() {

        List<Passenger> list=(List<Passenger>)this.passengerRepository.findAll();
        return list;
    }


    // get single PassengerService by id
    public Passenger getPassengerById(int id) {
        Passenger passenger = null;
        passenger=this.passengerRepository.findById(id);
        return passenger;
    }





    // Adding the PassengerService
    public Passenger addPassenger(Passenger bg) {
        Passenger result=passengerRepository.save(bg);
        return result;
    }


    // delete PassengerService
    public void deletePassenger(int bid) {
        passengerRepository.deleteById(bid);

    }



    // update the PassengerService
    public void updatePassenger(Passenger passenger, int blogId) {
        passenger.setPassengerId(blogId);
        passengerRepository.save(passenger);

    }
}
