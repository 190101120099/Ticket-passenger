package com.ticket.service;

import com.ticket.entities.Ticket;
import com.ticket.repository.TicketRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class TicketService {


    @Autowired
    private TicketRepository ticketRepository;


    // get all  TicketService
    public List<Ticket> getAllTickets() {
        List<Ticket> list=(List<Ticket>)this.ticketRepository.findAll();
        return list;
    }


    // get single  TicketService  by id
 public Ticket getTicketById(int id){
        Ticket ticket=null;
        ticket=this.ticketRepository.FindByID(id);
     return ticket;
 }


    // Adding the  TicketService
    public Ticket addTicket(Ticket b) {
        Ticket result=ticketRepository.save(b);
        return result;
    }



    // Delete TicketService by id
    public void deleteTicket(int bid) {
        ticketRepository.deleteById(bid);
    }



    // update the  TicketService
    public void updateTicket(Ticket ticket, int ticketId) {
        ticket.setTicketId(ticketId);
        ticketRepository.save(ticket);
    }

}
